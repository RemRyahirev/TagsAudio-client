MP3 Encoder
===============

Dummy app to test node-wekbit using an external process, coffee-script 
and backbone on both windows and OSX
