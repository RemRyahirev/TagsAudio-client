# Sample apps for node-webkit

Here are some sample apps for [node-webkit](https://github.com/rogerwang/node-webkit),
some of them are modified from [GoogleChrome/chrome-app-samples](https://github.com/GoogleChrome/chrome-app-samples).

Please visit [node-webkit group](http://groups.google.com/group/node-webkit) for discussions.
